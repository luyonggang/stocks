package com.michael.databindingdemo.twowaybinding;

public class LoginModel
{
    //用户名
    public String userName;
    //记住用户登录信息
    public boolean rememberMe;
}
