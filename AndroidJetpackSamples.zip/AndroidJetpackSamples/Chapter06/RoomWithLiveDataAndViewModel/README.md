# RoomWithLiveDataAndViewModel
Combine Room with LiveData and ViewModel.
