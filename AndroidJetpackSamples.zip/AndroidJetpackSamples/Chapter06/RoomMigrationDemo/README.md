# RoomMigrationDemo
Shows how to upgrade Room database.
