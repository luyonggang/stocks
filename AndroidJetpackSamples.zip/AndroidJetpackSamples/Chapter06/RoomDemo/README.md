# RoomDemo
Shows how to use Room in Android.
