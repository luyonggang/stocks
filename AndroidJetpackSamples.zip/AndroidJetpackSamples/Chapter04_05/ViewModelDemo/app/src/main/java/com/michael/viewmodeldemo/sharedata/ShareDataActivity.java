package com.michael.viewmodeldemo.sharedata;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.michael.viewmodeldemo.R;

public class ShareDataActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_data);
    }
}
