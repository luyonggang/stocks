# LifecycleServiceDemo
Shows how to use LifecycleService in Android.
