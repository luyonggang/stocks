# LifecycleDemo
Shows how to use LifeCycle in Activity or Fragment.
