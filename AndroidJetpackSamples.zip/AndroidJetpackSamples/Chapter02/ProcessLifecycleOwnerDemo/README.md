# ProcessLifecycleOwnerDemo
Shows how to use ProcessLifecycleOwner in Android.
