# SafeArgsDemo
Shows how to use safe args in AndroidStudio.
