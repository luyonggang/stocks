package com.michael.navigationuidemo;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * 应用程序的入口
 * */
public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
